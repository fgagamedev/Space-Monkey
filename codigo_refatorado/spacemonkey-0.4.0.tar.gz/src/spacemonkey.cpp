#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>

#include "draw.h"
#include "video.h"

int main()
{
	init_sdl();
	setup_window();
	SDL_Surface *screen = setup_video();
	SDL_Delay(3000);
	init_map1(screen);
	return 0;
}


