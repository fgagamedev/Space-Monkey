#ifndef VIDEO_H
#define VIDEO_H

#include <SDL/SDL.h>

extern void init_sdl();
extern void setup_window();
extern SDL_Surface *setup_video();



#endif
