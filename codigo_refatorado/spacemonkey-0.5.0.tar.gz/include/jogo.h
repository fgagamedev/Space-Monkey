#ifndef CLASS_JOGO 
#define CLASS_JOGO

using namespace std;

/**
classe que define o jogo
*/
class Jogo
{
private:
	
public:
	//inicia de fato o jogo
	void rodarJogo();
};


#endif

